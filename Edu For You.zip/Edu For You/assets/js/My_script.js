// const toggleButton = document.getElementById('dark-mode-toggle');
// const body = document.body;

// toggleButton.addEventListener('click', () => {
//     body.classList.toggle('dark-mode');

//     const icon = toggleButton.querySelector('i');
//     if (body.classList.contains('dark-mode')) {
//         icon.classList.remove('fa-moon');
//         icon.classList.add('fa-sun');
//     } else {
//         icon.classList.remove('fa-sun');
//         icon.classList.add('fa-moon');
//     }
// });
